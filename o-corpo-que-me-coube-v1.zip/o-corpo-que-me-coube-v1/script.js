const scenes = {
  eyes: {
    number: "01",
    title: "olhos",
    prose: [
      "Antes de aprender a escolher o que ver, você aprendeu a calcular o olhar dos outros.",
      "Há uma diferença entre ser vista e ser vigiada. O espelho espera: desta vez, quem decide a distância é você."
    ],
    options: [
      {
        id: "sustain",
        label: "Eu sustento o olhar.",
        tone: "confronto",
        token: "não desvio",
        response: "O papel junto aos olhos se firma. Você não precisa diminuir a própria presença para caber na visão de ninguém.",
        final: "Sustento o olhar até que ele deixe de ser uma sentença."
      },
      {
        id: "fissure",
        label: "Eu escolho a fresta.",
        tone: "cuidado",
        token: "uma fresta",
        response: "Nem toda proteção é fuga. Uma abertura pequena também pode ser uma medida exata de liberdade.",
        final: "Escolho a fresta por onde posso ver sem me abandonar."
      },
      {
        id: "inside",
        label: "Eu olho por dentro.",
        tone: "invencao",
        token: "o avesso",
        response: "Atrás da imagem, outra paisagem começa. Não é segredo: é um ponto de vista que ainda não tinha nome.",
        final: "Olho por dentro e encontro um avesso que também é paisagem."
      }
    ]
  },
  mouth: {
    number: "02",
    title: "boca",
    prose: [
      "Minha boca conheceu o silêncio antes de conhecer a própria voz. Guardou respostas que chegaram tarde e desejos que pareciam grandes demais para serem ditos.",
      "Agora ela vibra um pouco. Não porque perdeu o medo, mas porque cansou de confundir silêncio com segurança.",
      "Em casa, eu sabia quando uma conversa tinha terminado mesmo que ninguém dissesse. Bastava o modo como um prato era colocado na pia ou a televisão aumentava de volume. Eu guardava a frase que estava preparando e, algum tempo depois, já não sabia se ainda queria dizê-la ou se só queria ter sido capaz.",
      "Muitas respostas ficaram prontas no caminho. Eu as dizia sozinha, andando depressa, repetindo exatamente onde faria a pausa e qual palavra não permitiria que me interrompessem. Quando chegava diante da pessoa, porém, a frase parecia escrita para outra boca. Eu mudava uma palavra, depois outra, até que já não dissesse o que precisava.",
      "Também houve dias em que falei. Não com a voz firme que imagino quando refaço a cena, mas depressa, tropeçando, acrescentando explicações que ninguém havia pedido. Depois passei horas examinando o rosto de quem ouviu, procurando saber se eu tinha ido longe demais. Quase nunca me perguntava se tinha ido longe o bastante.",
      "Ainda tenho vontade de ensaiar antes. Às vezes ensaio. Mas começo a reconhecer que uma voz pode tremer sem deixar de ser minha. A frase não precisa sair inteira para existir. Posso dizê-la aos poucos e continuar quando houver ar."
    ],
    options: [
      {
        id: "desire",
        label: "Eu digo o desejo inteiro.",
        tone: "confronto",
        token: "desejo inteiro",
        response: "A boca não pede desculpas pelo tamanho da frase. Algumas palavras só existem quando são pronunciadas sem diminutivo.",
        final: "Digo o desejo inteiro, sem aparar suas bordas para tranquilizar a sala."
      },
      {
        id: "broken",
        label: "Eu deixo a voz sair quebrada.",
        tone: "cuidado",
        token: "voz imperfeita",
        response: "A voz falha e, ainda assim, chega. A perfeição era apenas mais uma condição inventada para adiar a fala.",
        final: "Deixo a voz sair quebrada, porque uma voz imperfeita ainda é minha."
      },
      {
        id: "language",
        label: "Eu invento outra língua.",
        tone: "invencao",
        token: "língua nova",
        response: "Entre aquilo que você herdou e aquilo que ainda não sabe dizer, nasce uma gramática que só este corpo entende.",
        final: "Invento outra língua quando as palavras recebidas já não alcançam o que sinto."
      }
    ]
  },
  throat: {
    number: "03",
    title: "garganta",
    prose: [
      "Há nomes que atravessam a garganta como se fossem destino: forte, difícil, exagerada, insuficiente.",
      "Alguns foram repetidos tantas vezes que aprenderam a soar como sua própria voz. Mas nem tudo o que mora no corpo nasceu nele.",
      "Forte era dito quando eu suportava. Difícil, quando perguntava por quê. Exagerada, quando o que doía não cabia na medida de quem escutava. Insuficiente quase nunca precisava ser pronunciado. Eu o reconhecia no silêncio depois de mostrar alguma coisa que tinha feito.",
      "Com o tempo, aprendi a usar esses nomes antes que outra pessoa usasse. Eu mesma dizia que estava exagerando, que era complicada, que não tinha feito o bastante. Parecia menos perigoso entregar a acusação já pronta. Às vezes até riam comigo, e por alguns minutos eu acreditava que tinha escapado.",
      "Mas o corpo não entendia a brincadeira. A garganta fechava do mesmo modo. Eu bebia água, pigarreava, procurava uma palavra menor. Quem estava diante de mim via uma hesitação. Eu sentia todos os nomes tentando passar ao mesmo tempo.",
      "Hoje, quando um deles aparece, tento perguntar de quem é a voz. Nem sempre sei responder. Algumas já perderam o rosto de onde vieram. Ainda assim, posso não repeti-las. Posso deixar que parem na garganta e saiam de mim sem se transformar outra vez em definição."
    ],
    options: [
      {
        id: "fear",
        label: "Eu nomeio o medo.",
        tone: "confronto",
        token: "medo nomeado",
        response: "Quando recebe um nome, o medo perde a capacidade de fingir que é o mundo inteiro.",
        final: "Nomeio o medo para que ele volte a ter tamanho."
      },
      {
        id: "interval",
        label: "Eu respiro antes de responder.",
        tone: "cuidado",
        token: "um intervalo",
        response: "O intervalo não é ausência. É o espaço onde sua resposta deixa de pertencer à urgência dos outros.",
        final: "Respiro antes de responder e faço do intervalo uma escolha."
      },
      {
        id: "return-name",
        label: "Eu devolvo o nome que me deram.",
        tone: "invencao",
        token: "nome próprio",
        response: "A garganta se abre. O nome antigo cai sem estrondo; no lugar dele, você não põe uma definição, mas uma possibilidade.",
        final: "Devolvo o nome que me deram e deixo espaço para um nome ainda meu."
      }
    ]
  },
  chest: {
    number: "04",
    title: "peito",
    prose: [
      "Carrego no peito casas que já não existem do mesmo modo. Há vozes, portões, panelas, perdas e pequenas alegrias respirando juntas.",
      "Às vezes não consigo lembrar das texturas, das cores, dos cheiros, mas algo toca. Toca em mim e no fundo do meu peito.",
      "Uma das casas tinha um corredor que, na minha lembrança, é comprido demais. Se tento percorrê-lo, encontro primeiro o barulho das panelas, depois uma porta que talvez não ficasse daquele lado. Já perguntei a quem morou comigo. Disseram que o corredor era pequeno. Não sei qual de nós está lembrando a casa certa.",
      "Também não consigo reconstruir todas as vozes. Algumas chegam sem palavras, apenas com o ritmo de quem falava enquanto fazia outra coisa. Uma risada atravessa a cozinha. Alguém chama do portão. Quando tento ver o rosto, a lembrança oferece outra cena.",
      "Há perdas que reconheço pelo espaço que deixaram e alegrias que só percebi depois que acabaram. Naquele tempo, talvez fossem apenas uma tarde, uma comida repartida, gente demais numa sala. Hoje se aproximam quando sinto um cheiro parecido ou quando a luz entra de certo modo pela janela.",
      "Não sei se carrego as casas ou se foram elas que encontraram um lugar em mim. Sei que mudaram enquanto eu também mudava. Quando volto, mesmo que seja apenas pensando, nenhuma permanece onde deixei. Ainda assim, alguma coisa reconhece a entrada."
    ],
    options: [
      {
        id: "same-memory",
        label: "Também tenho memórias desse tipo.",
        tone: "cuidado",
        token: "algo toca",
        response: "Então talvez você conheça esse instante em que uma casa volta sem voltar inteira. Não vejo todos os cômodos. Não encontro tudo como deixei. Mesmo assim, alguma coisa em mim reconhece o caminho.",
        final: "Também carrego lembranças que perderam suas formas, mas ainda sabem tocar meu peito."
      },
      {
        id: "toward-head",
        label: "Quero entender o que meu peito reconheceu antes de mim.",
        tone: "invencao",
        token: "peito e cabeça",
        response: "",
        nextScene: "eyes",
        final: "Levo para a cabeça aquilo que o peito reconheceu antes que eu pudesse explicar."
      },
      {
        id: "no-sensation",
        label: "Não sinto sensações como essa.",
        tone: "invencao",
        token: "uma memória sem toque",
        response: "Há lembranças que não chegam ao corpo. Sei que aconteceram porque alguém contou, porque existe uma fotografia, porque aprendi a repeti-las. Procuro o que deveria sentir e não encontro. Talvez o vazio também faça parte do que ficou.",
        final: "Nem toda lembrança me toca; algumas permanecem como histórias que sei, mas não alcanço."
      }
    ]
  },
  nape: {
    number: "05",
    title: "nuca",
    prose: [
      "A nuca guarda aquilo que você não consegue vigiar: os olhos que ficam para trás, a expectativa alheia, a pergunta sobre quem comenta quando você sai.",
      "Viver olhando para todos os lados também é uma forma de nunca chegar inteira a lugar algum.",
      "Aprendi a reconhecer passos sem virar o rosto. Alguns eram rápidos, outros arrastavam um pouco o chinelo, outros paravam perto da porta antes de entrar. Meu corpo sabia quem vinha pelo corredor e começava a se organizar antes que eu tivesse certeza.",
      "Na rua, essa atenção ganhou outras tarefas. Eu observava reflexos nas vitrines, escutava o ritmo de quem caminhava atrás, mudava a bolsa de lado. Chegava ao destino sem saber dizer por onde tinha passado. A maior parte do caminho ficava ocupada pelo que poderia acontecer.",
      "Mesmo em lugares seguros, a nuca demorava a acreditar. Um riso atrás de mim podia ser apenas um riso, mas eu já procurava o que havia feito de errado. Às vezes me virava e ninguém estava olhando. Isso não impedia que a sensação continuasse.",
      "Tenho tentado chegar sem levar todos esses olhos comigo. Não consigo deixá-los de uma vez. Começo apoiando as costas na cadeira, escolhendo um lugar de onde não vejo a porta, permanecendo alguns minutos sem conferir quem entrou."
    ],
    options: [
      {
        id: "return-weight",
        label: "Eu não carrego todos os olhos.",
        tone: "confronto",
        token: "peso devolvido",
        response: "Alguns olhares escorrem dos ombros. Você percebe quanto esforço gastava sustentando julgamentos que nem sequer eram seus.",
        final: "Não carrego todos os olhos; devolvo a cada julgamento o peso que lhe pertence."
      },
      {
        id: "company",
        label: "Eu levo quem me sustentou.",
        tone: "cuidado",
        token: "companhia",
        response: "Nem toda presença atrás de você é ameaça. Algumas mãos antigas permanecem sem empurrar, apenas lembrando que ninguém se faz sozinho.",
        final: "Levo comigo quem me sustentou, sem transformar companhia em dívida."
      },
      {
        id: "direction",
        label: "Eu mudo a direção do corpo.",
        tone: "invencao",
        token: "outra direção",
        response: "O que estava atrás deixa de comandar o caminho. Você não precisa vencer a perseguição; pode inventar uma direção que ela desconhece.",
        final: "Mudo a direção do corpo e descubro caminhos que o medo ainda não aprendeu a seguir."
      }
    ]
  }
};

const sceneOrder = ["eyes", "mouth", "throat", "chest", "nape"];
const storageKey = "o-corpo-que-me-coube:v1";

const state = {
  started: false,
  choices: {},
  activeScene: null,
  travelling: false,
  soundOn: false,
  audio: null
};

const elements = {
  startScreen: document.querySelector("#startScreen"),
  startButton: document.querySelector("#startButton"),
  portraitBody: document.querySelector("#portraitBody"),
  readingRail: document.querySelector("#readingRail"),
  railEmpty: document.querySelector("#railEmpty"),
  scenePanel: document.querySelector("#scenePanel"),
  sceneKicker: document.querySelector("#sceneKicker"),
  sceneTitle: document.querySelector("#sceneTitle"),
  sceneProse: document.querySelector("#sceneProse"),
  choiceList: document.querySelector("#choiceList"),
  sceneAfter: document.querySelector("#sceneAfter"),
  closePanel: document.querySelector("#closePanel"),
  endingInvitation: document.querySelector("#endingInvitation"),
  readBodyButton: document.querySelector("#readBodyButton"),
  endingScreen: document.querySelector("#endingScreen"),
  endingLabel: document.querySelector("#endingLabel"),
  endingTitle: document.querySelector("#endingTitle"),
  endingDate: document.querySelector("#endingDate"),
  endingText: document.querySelector("#endingText"),
  collectedWords: document.querySelector("#collectedWords"),
  copyEnding: document.querySelector("#copyEnding"),
  printEnding: document.querySelector("#printEnding"),
  restartButton: document.querySelector("#restartButton"),
  closeEnding: document.querySelector("#closeEnding"),
  soundToggle: document.querySelector("#soundToggle"),
  soundLabel: document.querySelector("#soundLabel"),
  toast: document.querySelector("#toast"),
  aboutButton: document.querySelector("#aboutButton"),
  aboutDialog: document.querySelector("#aboutDialog"),
  closeAbout: document.querySelector("#closeAbout")
  ,bodyTravel: document.querySelector("#bodyTravel")
};

const travelImage = elements.bodyTravel.querySelector("img");
const travelImageReady = travelImage.decode().catch(() => {
  travelImage.src = elements.portraitBody.querySelector(".portrait-base").src;
  return travelImage.decode().catch(() => {});
});

const bodyCoordinates = {
  eyes: [50, 18],
  mouth: [50, 31],
  throat: [50, 41],
  chest: [50, 59],
  nape: [64, 37]
};

const longFormBridges = {
  eyes: [
    "Às vezes volto à cena e encontro detalhes que não estavam ali na vez anterior. Não sei se esqueci, se inventei ou se só agora consigo olhar para aquela parte. Minha lembrança não responde. Continua oferecendo imagens com a segurança de quem também pode estar mentindo.",
    "Pergunto a outras pessoas e recebo versões em que quase não me reconheço. Para alguém, foi uma tarde comum. Para mim, aquela tarde se estendeu por anos. As duas coisas podem ter acontecido no mesmo cômodo, sem que uma consiga corrigir a outra.",
    "Talvez a cabeça não guarde o passado. Talvez trabalhe sobre ele, deslocando uma cadeira, aproximando uma voz, apagando a cor de uma parede para que eu consiga continuar entrando naquela casa."
  ],
  mouth: [
    "Penso nas frases que só ficaram prontas depois. No caminho de volta, durante o banho, muitos anos mais tarde, encontrei as palavras exatas. Elas chegaram quando já não havia ninguém diante de mim para ouvi-las.",
    "Também houve o que eu disse e imediatamente quis recolher. A boca não permite essa volta. Depois que uma frase encontra o ar, passa a pertencer um pouco a quem a escutou, ao lugar em que foi dita e ao silêncio que veio depois.",
    "Hoje tento não exigir da minha voz uma coragem completa. Algumas coisas saem baixas, outras quebradas. Ainda assim, fazem um caminho entre dentro e fora que o silêncio sozinho não faria."
  ],
  throat: [
    "Há palavras que conheço por inteiro e mesmo assim não atravessam. Param num lugar do corpo onde explicação nenhuma consegue empurrá-las. Quanto mais tento falar com clareza, mais percebo o esforço de cada músculo.",
    "Aprendi a mudar de assunto, beber água, sorrir na hora exata. Quem estava comigo talvez tenha chamado isso de calma. Eu sabia quanto movimento era necessário para manter uma frase parada.",
    "Nem sempre falar resolve. Mas começo a reconhecer o instante em que a garganta fecha e, antes de me culpar, tento escutar o que ela ainda está protegendo."
  ],
  chest: [
    "Algumas lembranças chegam primeiro como sensação. O coração acelera antes que eu reconheça o lugar; uma alegria aparece misturada a uma perda; sinto saudade de algo que, se me perguntarem, não sei descrever direito.",
    "As casas que carrego não permanecem iguais. Trocaram o portão, pintaram a parede, venderam os móveis, derrubaram uma parte. Dentro de mim, porém, continuam com medidas que talvez nunca tenham tido.",
    "Não quero transformar tudo em explicação. Há coisas que o peito sabe sem organizar, e talvez eu possa deixá-las respirar juntas sem obrigá-las a produzir uma versão definitiva da minha história."
  ],
  nape: [
    "Durante muito tempo senti o que estava atrás antes de olhar o que havia à frente. Um passo, uma mudança no ar, o silêncio repentino de uma conversa: qualquer coisa podia fazer meu corpo preparar uma defesa.",
    "Diziam que eu precisava relaxar. A palavra chegava como outra tarefa, mais uma coisa que eu deveria saber fazer corretamente. Ninguém explicava como convencer o corpo de que aquele instante não repetiria os anteriores.",
    "Agora, quando consigo, deixo as costas encontrarem apoio. Não é esquecer o que veio de trás. É experimentar por alguns segundos a possibilidade de não precisar vigiá-lo."
  ]
};

function regionForScene(sceneId) {
  if (bodyCoordinates[sceneId]) return sceneId;
  const index = Number(String(sceneId || "").replace("paper", ""));
  if (Number.isFinite(index) && discoveries?.[index]) {
    return discoveryRelations[discoveries[index][0]]?.[0] || "chest";
  }
  return "chest";
}

function animateTravelFragment(sceneId, direction) {
  const overlay = elements.bodyTravel;
  const figure = overlay.querySelector(".travel-figure");
  const fragment = document.querySelector(`.body-fragment[data-scene="${sceneId}"]`);
  const portrait = elements.portraitBody.querySelector(".portrait-base");
  const bounds = fragment.getBoundingClientRect();
  const imageBounds = portrait.getBoundingClientRect();
  const imageStyle = window.getComputedStyle(portrait);
  const image = figure.querySelector("img");
  // A small paper crop cannot fill the viewport without stretching its pixels.
  // Keep the approach visible while respecting the detail in the source image.
  const sourceScale = Math.min(
    travelImage.naturalWidth / imageBounds.width,
    travelImage.naturalHeight / imageBounds.height
  );
  const scale = Math.max(1.4, Math.min(
    3,
    sourceScale * 1.15,
    window.innerWidth * 0.65 / bounds.width,
    window.innerHeight * 0.65 / bounds.height
  ));
  const width = bounds.width * scale;
  const height = bounds.height * scale;

  overlay.classList.remove("is-entering", "is-returning");
  // Render at the enlarged size first, then animate from a smaller scale.
  // This avoids magnifying a low-resolution composited layer of the small crop.
  figure.style.left = `${bounds.left + (bounds.width - width) / 2}px`;
  figure.style.top = `${bounds.top + (bounds.height - height) / 2}px`;
  figure.style.width = `${width}px`;
  figure.style.height = `${height}px`;
  figure.style.clipPath = window.getComputedStyle(fragment).clipPath;
  figure.style.setProperty("--travel-x", `${window.innerWidth / 2 - bounds.left - bounds.width / 2}px`);
  figure.style.setProperty("--travel-y", `${window.innerHeight / 2 - bounds.top - bounds.height / 2}px`);
  figure.style.setProperty("--travel-start-scale", 1 / scale);

  // Keep the image aligned with the portrait, but expose only the selected paper.
  image.style.left = `${(imageBounds.left - bounds.left) * scale}px`;
  image.style.top = `${(imageBounds.top - bounds.top) * scale}px`;
  image.style.width = `${imageBounds.width * scale}px`;
  image.style.height = `${imageBounds.height * scale}px`;
  image.style.objectFit = imageStyle.objectFit;
  image.style.objectPosition = imageStyle.objectPosition;
  image.style.filter = imageStyle.filter;

  overlay.hidden = false;
  void overlay.offsetWidth;
  overlay.classList.add(direction);
}

function finishTravel() {
  elements.bodyTravel.hidden = true;
  elements.bodyTravel.classList.remove("is-entering", "is-returning");
  elements.portraitBody.classList.remove("is-travelling");
  document.querySelector(".mirror-zone").inert = false;
  document.querySelector(".topbar").inert = false;
  state.travelling = false;
}

async function travelToScene(nextScene) {
  if (state.travelling || !scenes[nextScene]) return;
  state.travelling = true;
  await travelImageReady;
  const currentScene = state.activeScene;
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const duration = reducedMotion ? 10 : 1320;
  const revealDelay = currentScene ? duration : 0;
  elements.portraitBody.classList.add("is-travelling");
  document.querySelector(".mirror-zone").inert = true;
  document.querySelector(".topbar").inert = true;
  elements.readingRail.hidden = true;

  playTransitionSound(currentScene ? "between" : "in");

  if (currentScene) {
    animateTravelFragment(currentScene, "is-returning");
    window.setTimeout(() => animateTravelFragment(nextScene, "is-entering"), revealDelay);
  } else animateTravelFragment(nextScene, "is-entering");

  window.setTimeout(() => {
    finishTravel();
    if (nextScene === "eyes") renderHeadNarrative("partida");
    else renderScene(nextScene);
  }, revealDelay + duration);
}

function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem(storageKey));
    if (!saved || typeof saved !== "object") return;

    for (const sceneId of sceneOrder) {
      const optionId = saved.choices?.[sceneId];
      if (scenes[sceneId].options.some((option) => option.id === optionId)) {
        state.choices[sceneId] = optionId;
      }
    }
  } catch {
    localStorage.removeItem(storageKey);
  }
}

function saveState() {
  localStorage.setItem(storageKey, JSON.stringify({ choices: state.choices }));
}

function selectedOption(sceneId) {
  if (!scenes[sceneId] || scenes[sceneId].discovery) return null;
  const optionId = state.choices[sceneId];
  return scenes[sceneId].options.find((option) => option.id === optionId) || null;
}

function completedCount() {
  return sceneOrder.filter((sceneId) => selectedOption(sceneId)).length;
}

function dominantTone() {
  const counts = { confronto: 0, cuidado: 0, invencao: 0 };
  sceneOrder.forEach((sceneId) => {
    const option = selectedOption(sceneId);
    if (option) counts[option.tone] += 1;
  });

  const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]);
  if (!sorted[0][1] || sorted[0][1] === sorted[1][1]) return "travessia";
  return sorted[0][0];
}

function updateInterface() {
  const count = completedCount();
  elements.endingInvitation.hidden = true;
  const tone = dominantTone();
  elements.portraitBody.dataset.tone = tone === "travessia" ? "" : tone;

  document.querySelectorAll("[data-scene]").forEach((button) => {
    const sceneId = button.dataset.scene;
    const option = selectedOption(sceneId);
    button.classList.toggle("is-complete", Boolean(option));
    button.classList.toggle("is-active", state.activeScene === sceneId);

    const word = button.querySelector(".fragment-word");
    if (word) word.textContent = option?.token || "";

    if (button.matches("button")) {
      const region = scenes[sceneId].title;
      button.setAttribute(
        "aria-label",
        option ? `Reabrir ${region}. Fragmento escolhido: ${option.token}` : `Abrir o fragmento: ${region}`
      );
    }
  });

  document.querySelectorAll("[data-region]").forEach((item) => {
    item.classList.toggle("is-complete", Boolean(selectedOption(item.dataset.region)));
  });

  const hasProgress = count > 0;
  elements.startButton.setAttribute("aria-label", hasProgress ? "Continuar a experiência pelo corpo" : "Entrar na experiência pelo corpo");
}

function startGame() {
  if (state.started) return;
  state.started = true;
  elements.startScreen.classList.add("is-leaving");
  window.setTimeout(() => {
    elements.startScreen.hidden = true;
    const firstIncomplete = sceneOrder.find((sceneId) => !selectedOption(sceneId));
    document.querySelector("#aboutButton")?.focus({ preventScroll: true });
  }, window.matchMedia("(prefers-reduced-motion: reduce)").matches ? 0 : 1250);
}

function expandedDiscoveryProse(scene) {
  const primaryRegion = scene.paths?.find((path) => path.next)?.next || "chest";
  return [
    ...scene.prose,
    ...(scene.stay?.[1] || []),
    ...(longFormBridges[primaryRegion] || longFormBridges.chest)
  ];
}

function renderScene(sceneId) {
  if (sceneId === "eyes") { renderHeadNarrative("partida"); return; }
  const scene = scenes[sceneId];
  if (!scene) return;
  elements.readingRail.classList.add("literary-reading");

  state.activeScene = sceneId;
  elements.railEmpty.hidden = true;
  elements.scenePanel.hidden = false;
  elements.readingRail.hidden = false;
  elements.readingRail.classList.add("is-open");
  elements.readingRail.scrollTop = 0;
  elements.sceneKicker.textContent = "";
  elements.sceneTitle.textContent = scene.title;
  const openingProse = scene.discovery ? expandedDiscoveryProse(scene) : scene.prose;
  elements.sceneProse.innerHTML = openingProse.map((paragraph) => `<p>${paragraph}</p>`).join("");
  elements.sceneAfter.hidden = true;
  elements.sceneAfter.innerHTML = "";
  elements.choiceList.hidden = false;
  elements.choiceList.innerHTML = "";

  if (scene.discovery) {
    elements.choiceList.hidden = false;
    elements.sceneAfter.hidden = false;
    scene.paths.forEach((path, index) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "choice-button";
      button.innerHTML = `
        <span class="choice-letter" aria-hidden="true">${String.fromCharCode(65 + index)}</span>
        <span class="choice-copy">${path.label}</span>
      `;
      button.addEventListener("click", () => {
        if (path.next && scenes[path.next]) travelToScene(path.next);
        else {
          renderDiscoveryContinuation(scene, 0);
        }
      });
      elements.choiceList.append(button);
    });
    const leave = document.createElement("button");
    leave.type = "button";
    leave.className = "return-button";
    leave.textContent = "voltar ao corpo";
    leave.addEventListener("click", closeScene);
    elements.sceneAfter.append(leave);
    updateInterface();
    elements.closePanel.focus({preventScroll:true});
    return;
  }
  const current = selectedOption(sceneId);
  scene.options.forEach((option, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "choice-button";
    if (current?.id === option.id) button.classList.add("is-selected");
    button.dataset.option = option.id;
    button.innerHTML = `
      <span class="choice-letter" aria-hidden="true">${String.fromCharCode(65 + index)}</span>
      <span class="choice-copy">${option.label}</span>
    `;
    button.addEventListener("click", () => chooseOption(sceneId, option.id));
    elements.choiceList.append(button);
  });

  updateInterface();
  if (window.innerWidth <= 860) {
    window.setTimeout(() => elements.sceneTitle.focus?.(), 560);
  }
}

function chooseOption(sceneId, optionId) {
  const scene = scenes[sceneId];
  const option = scene.options.find((item) => item.id === optionId);
  if (!option) return;

  state.choices[sceneId] = optionId;
  saveState();
  updateInterface();

  if (option.nextScene && scenes[option.nextScene]) {
    travelToScene(option.nextScene);
    return;
  }

  elements.choiceList.hidden = true;
  elements.sceneAfter.hidden = false;
  elements.sceneAfter.innerHTML = `
    <blockquote>${option.response}</blockquote>

    <button class="return-button" type="button">${completedCount() === 5 ? "ler o corpo inteiro" : "voltar ao espelho"}</button>
  `;

  elements.sceneAfter.querySelector(".return-button").addEventListener("click", () => {
    if (completedCount() === 5) {
      showEnding();
    } else {
      closeScene();
    }
  });
}

function renderDiscoveryContinuation(scene, step) {
  const passages = scene.stay || [];
  const relatedRegions = scene.paths?.filter((path) => path.next).map((path) => path.next) || [];
  const secondaryRegion = relatedRegions[1] || relatedRegions[0] || "chest";
  const passage = step === 1
    ? [...(longFormBridges[secondaryRegion] || longFormBridges.chest), ...(passages[2] || [])]
    : step === 2
      ? ["O fragmento não termina porque saio dele. Antes de voltar ao corpo, deixo que permaneça aberto, sem obrigá-lo a oferecer uma conclusão."]
      : passages[0];
  if (!passage) return;

  elements.scenePanel.classList.remove("discovery-continuation");
  void elements.scenePanel.offsetWidth;
  elements.scenePanel.classList.add("discovery-continuation");
  elements.sceneTitle.textContent = scene.title;
  elements.sceneProse.replaceChildren(...passage.map((text) => {
    const paragraph = document.createElement("p");
    paragraph.textContent = text;
    return paragraph;
  }));
  elements.choiceList.hidden = true;
  elements.sceneAfter.hidden = false;

  const button = document.createElement("button");
  button.type = "button";
  button.className = "return-button";
  const hasNext = step < passages.length - 1;
  button.textContent = hasNext ? "continuar" : "voltar ao corpo";
  button.addEventListener("click", () => {
    if (hasNext) renderDiscoveryContinuation(scene, step + 1);
    else closeScene();
  });
  elements.sceneAfter.replaceChildren(button);
  elements.readingRail.scrollTop = 0;
}

function closeScene() {
  if (state.travelling || !state.activeScene) return;
  const priorScene = state.activeScene;
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const finishDelay = reducedMotion ? 10 : 1320;
  state.travelling = true;
  elements.portraitBody.classList.add("is-travelling");
  document.querySelector(".mirror-zone").inert = true;
  document.querySelector(".topbar").inert = true;

  playTransitionSound("out");

  state.activeScene = null;
  animateTravelFragment(priorScene, "is-returning");
  elements.readingRail.hidden = true;
  elements.readingRail.classList.remove("is-open", "literary-reading");
  elements.scenePanel.hidden = true;
  elements.railEmpty.hidden = false;
  window.setTimeout(() => {
    finishTravel();
    updateInterface();
    document.querySelector(`.body-fragment[data-scene="${priorScene}"]`)?.focus({ preventScroll: true });
  }, finishDelay);
}

function renderHeadNarrative(nodeId) {
  const node = headNarrative[nodeId];
  if (!node) throw new Error("Passagem desconhecida: " + nodeId);
  state.activeScene = "eyes";
  elements.railEmpty.hidden = true;
  elements.scenePanel.hidden = false;
  elements.readingRail.hidden = false;
  elements.readingRail.classList.add("is-open", "literary-reading");
  elements.sceneKicker.textContent = "";
  elements.sceneTitle.textContent = node.title;
  elements.sceneProse.replaceChildren(...node.prose.map(text => {
    const p = document.createElement("p"); p.textContent = text; return p;
  }));
  elements.sceneAfter.hidden = false;
  elements.sceneAfter.replaceChildren();
  elements.choiceList.hidden = false;
  elements.choiceList.replaceChildren(...node.choices.map((choice, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "choice-button";
    button.innerHTML = `
      <span class="choice-letter" aria-hidden="true">${String.fromCharCode(65 + index)}</span>
      <span class="choice-copy">${choice.label}</span>
    `;
    button.addEventListener("click", () => {
      if (choice.nextScene) travelToScene(choice.nextScene);
      else renderHeadNarrative(choice.next);
    });
    return button;
  }));
  const leave = document.createElement("button");
  leave.type = "button";
  leave.className = "return-button";
  leave.textContent = "voltar ao corpo";
  leave.addEventListener("click", closeScene);
  elements.sceneAfter.append(leave);
  // Keep the portrait and header inactive while the independent reading dialog is open.
  document.querySelector(".mirror-zone").inert = true;
  document.querySelector(".topbar").inert = true;
  elements.sceneTitle.focus({ preventScroll: true });
  elements.readingRail.scrollTop = 0;
  updateInterface();
}

function endingContent() {
  const tone = dominantTone();
  const endings = {
    confronto: {
      label: "corpo que não pede licença",
      title: "Eu fico do meu tamanho.",
      opening: "O corpo que aparece aqui não ficou mais fácil de carregar. Ficou impossível de reduzir."
    },
    cuidado: {
      label: "corpo que cabe em si",
      title: "Eu me recebo inteira.",
      opening: "O corpo que aparece aqui não se fechou contra o mundo. Ele aprendeu a não sair de si para acomodar todo mundo."
    },
    invencao: {
      label: "corpo ainda em construção",
      title: "Eu não termino na moldura.",
      opening: "O corpo que aparece aqui não procura uma versão definitiva. Ele usa cada borda como começo."
    },
    travessia: {
      label: "corpo em travessia",
      title: "Eu mudo sem desaparecer.",
      opening: "O corpo que aparece aqui não escolheu uma única maneira de existir. Fez da contradição um lugar habitável."
    }
  };

  const chosen = sceneOrder.map((sceneId) => selectedOption(sceneId));
  return {
    ...endings[tone],
    paragraphs: [
      endings[tone].opening,
      `${chosen[0].final} ${chosen[1].final}`,
      `${chosen[2].final} ${chosen[3].final} ${chosen[4].final}`,
      "Isto não é retrato nem promessa. É a forma provisória que encontrei para permanecer em movimento sem pedir perdão por ocupar espaço. Amanhã, talvez, eu me componha de outro modo."
    ],
    tokens: chosen.map((option) => option.token)
  };
}

function showEnding() {
  if (completedCount() !== 5) return;

  const ending = endingContent();
  elements.endingLabel.textContent = ending.label;
  elements.endingTitle.textContent = ending.title;
  elements.endingDate.textContent = new Intl.DateTimeFormat("pt-BR", {
    day: "2-digit",
    month: "long",
    year: "numeric"
  }).format(new Date());
  elements.endingText.innerHTML = ending.paragraphs.map((paragraph) => `<p>${paragraph}</p>`).join("");
  elements.collectedWords.innerHTML = ending.tokens
    .map((token, index) => `<span style="--tilt:${index % 2 ? 1.5 : -1.5}deg">${token}</span>`)
    .join("");
  elements.endingScreen.hidden = false;
  elements.endingScreen.scrollTop = 0;
  document.body.style.overflow = "hidden";
  window.setTimeout(() => elements.closeEnding.focus(), 80);
}

function closeEnding() {
  elements.endingScreen.hidden = true;
  document.body.style.overflow = "";
  elements.readingRail.hidden = true;
  elements.readingRail.classList.remove("is-open");
  elements.scenePanel.hidden = true;
  elements.railEmpty.hidden = false;
  state.activeScene = null;
  updateInterface();
  elements.readBodyButton.focus({ preventScroll: true });
}

function resetGame() {
  localStorage.removeItem(storageKey);
  state.choices = {};
  state.activeScene = null;
  elements.endingScreen.hidden = true;
  elements.scenePanel.hidden = true;
  elements.railEmpty.hidden = false;
  elements.readingRail.hidden = true;
  elements.readingRail.classList.remove("is-open");
  document.body.style.overflow = "";
  updateInterface();
  showToast("O espelho foi limpo.");
}

function endingAsText() {
  const ending = endingContent();
  return [
    "O CORPO QUE ME COUBE",
    ending.label.toUpperCase(),
    "",
    ending.title,
    "",
    ...ending.paragraphs,
    "",
    `Fragmentos: ${ending.tokens.join(" · ")}`
  ].join("\n");
}

async function copyEnding() {
  const text = endingAsText();
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const input = document.createElement("textarea");
    input.value = text;
    input.style.position = "fixed";
    input.style.opacity = "0";
    document.body.append(input);
    input.select();
    document.execCommand("copy");
    input.remove();
  }
  showToast("Seu corpo-texto foi copiado.");
}

function showToast(message) {
  elements.toast.textContent = message;
  elements.toast.classList.add("is-visible");
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => elements.toast.classList.remove("is-visible"), 2600);
}

function createAmbientSound() {
  if (state.audio) return state.audio;
  const AudioContext = window.AudioContext || window.webkitAudioContext;
  if (!AudioContext) return null;

  const context = new AudioContext();
  const master = context.createGain();
  const compressor = context.createDynamicsCompressor();
  master.gain.value = 0;
  compressor.threshold.value = -18;
  compressor.knee.value = 18;
  compressor.ratio.value = 5;
  compressor.attack.value = 0.012;
  compressor.release.value = 0.28;
  master.connect(compressor).connect(context.destination);

  const low = context.createOscillator();
  const lowGain = context.createGain();
  low.type = "sine";
  low.frequency.value = 54;
  lowGain.gain.value = 0.052;
  low.connect(lowGain).connect(master);
  low.start();

  const buffer = context.createBuffer(1, context.sampleRate * 2, context.sampleRate);
  const data = buffer.getChannelData(0);
  for (let index = 0; index < data.length; index += 1) {
    data[index] = (Math.random() * 2 - 1) * 0.25;
  }
  const noise = context.createBufferSource();
  const filter = context.createBiquadFilter();
  const noiseGain = context.createGain();
  noise.buffer = buffer;
  noise.loop = true;
  filter.type = "lowpass";
  filter.frequency.value = 320;
  noiseGain.gain.value = 0.068;
  noise.connect(filter).connect(noiseGain).connect(master);
  noise.start();

  state.audio = { context, master };
  return state.audio;
}

async function toggleSound() {
  const audio = createAmbientSound();
  if (!audio) {
    showToast("O som não está disponível neste navegador.");
    return;
  }

  if (audio.context.state === "suspended") await audio.context.resume();
  state.soundOn = !state.soundOn;
  audio.master.gain.cancelScheduledValues(audio.context.currentTime);
  audio.master.gain.linearRampToValueAtTime(state.soundOn ? 1 : 0, audio.context.currentTime + 0.65);
  elements.soundToggle.setAttribute("aria-pressed", String(state.soundOn));
  elements.soundLabel.textContent = state.soundOn ? "som ligado" : "som";
}

function playFragmentSound(sceneId) {
  if (!state.soundOn || !state.audio) return;
  const { context, master } = state.audio;
  const now = context.currentTime;
  const region = regionForScene(sceneId);
  const regionIndex = ["eyes", "mouth", "throat", "chest", "nape"].indexOf(region);
  const hash = [...String(sceneId)].reduce((total, character) => ((total * 31) + character.charCodeAt(0)) >>> 0, 17);
  const scales = [
    [0, 3, 7, 10, 14],
    [0, 2, 5, 9, 12],
    [0, 4, 7, 11, 14],
    [0, 5, 7, 10, 12]
  ];
  const scale = scales[hash % scales.length];
  const base = 92 + Math.max(regionIndex, 0) * 24 + (hash % 19);
  const waveform = ["sine", "triangle", "sine", "triangle", "sine"][Math.max(regionIndex, 0)];

  scale.slice(0, 3).forEach((semitones, index) => {
    const tone = context.createOscillator();
    const toneGain = context.createGain();
    const start = now + index * 0.045;
    tone.type = waveform;
    tone.frequency.setValueAtTime(base * Math.pow(2, semitones / 12), start);
    tone.detune.value = ((hash >> (index * 3)) % 11) - 5;
    toneGain.gain.setValueAtTime(0.0001, start);
    toneGain.gain.exponentialRampToValueAtTime(0.075 - index * 0.012, start + 0.025);
    toneGain.gain.exponentialRampToValueAtTime(0.0001, start + 0.34 + index * 0.055);
    tone.connect(toneGain).connect(master);
    tone.start(start);
    tone.stop(start + 0.48);
  });

  const buffer = context.createBuffer(1, context.sampleRate * 0.2, context.sampleRate);
  const data = buffer.getChannelData(0);
  for (let index = 0; index < data.length; index += 1) {
    const envelope = 1 - index / data.length;
    data[index] = (Math.random() * 2 - 1) * envelope * envelope;
  }
  const source = context.createBufferSource();
  const filter = context.createBiquadFilter();
  const gain = context.createGain();
  filter.type = "bandpass";
  filter.frequency.value = 620 + (hash % 7) * 190;
  filter.Q.value = 0.65 + (hash % 5) * 0.12;
  gain.gain.value = 0.12;
  source.buffer = buffer;
  source.connect(filter).connect(gain).connect(master);
  source.start(now);
}

function playTransitionSound(direction = "in") {
  if (!state.soundOn || !state.audio) return;
  const { context, master } = state.audio;
  const now = context.currentTime;
  const duration = direction === "between" ? 1.65 : 1.35;
  const buffer = context.createBuffer(1, Math.ceil(context.sampleRate * duration), context.sampleRate);
  const data = buffer.getChannelData(0);

  for (let index = 0; index < data.length; index += 1) {
    const progress = index / data.length;
    const softEdge = Math.sin(Math.PI * progress);
    data[index] = (Math.random() * 2 - 1) * softEdge;
  }

  const breath = context.createBufferSource();
  const filter = context.createBiquadFilter();
  const breathGain = context.createGain();
  const opens = direction !== "out";
  breath.buffer = buffer;
  filter.type = "bandpass";
  filter.Q.value = 0.55;
  filter.frequency.setValueAtTime(opens ? 260 : 1250, now);
  filter.frequency.exponentialRampToValueAtTime(opens ? 1450 : 240, now + duration);
  breathGain.gain.setValueAtTime(0.0001, now);
  breathGain.gain.exponentialRampToValueAtTime(0.16, now + duration * 0.42);
  breathGain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
  breath.connect(filter).connect(breathGain).connect(master);
  breath.start(now);

  const pulse = context.createOscillator();
  const pulseGain = context.createGain();
  pulse.type = "sine";
  pulse.frequency.setValueAtTime(opens ? 48 : 76, now);
  pulse.frequency.exponentialRampToValueAtTime(opens ? 82 : 44, now + duration);
  pulseGain.gain.setValueAtTime(0.0001, now);
  pulseGain.gain.exponentialRampToValueAtTime(0.095, now + duration * 0.34);
  pulseGain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
  pulse.connect(pulseGain).connect(master);
  pulse.start(now);
  pulse.stop(now + duration + 0.02);
}

function registerWebMcpTools() {
  const context = document.modelContext;
  if (!context?.registerTool) return;

  const reportRegistrationError = () => {};
  const commonAnnotations = { untrustedContentHint: false };

  try {
    void Promise.resolve(
      context.registerTool({
        name: "choose_body_fragments",
        title: "Escolher fragmentos do corpo",
        description: "Registra uma ou mais escolhas narrativas nas cinco regiões do corpo e atualiza a experiência visível.",
        inputSchema: {
          type: "object",
          properties: {
            eyes: { type: "string", enum: ["sustain", "fissure", "inside"] },
            mouth: { type: "string", enum: ["desire", "broken", "language"] },
            throat: { type: "string", enum: ["fear", "interval", "return-name"] },
            chest: { type: "string", enum: ["same-memory", "toward-head", "no-sensation"] },
            nape: { type: "string", enum: ["return-weight", "company", "direction"] }
          },
          minProperties: 1,
          additionalProperties: false
        },
        annotations: { ...commonAnnotations, readOnlyHint: false },
        execute(input) {
          if (!input || typeof input !== "object" || Array.isArray(input)) {
            throw new TypeError("Envie ao menos uma região e uma escolha válida.");
          }

          const entries = Object.entries(input);
          if (!entries.length) throw new TypeError("Nenhum fragmento foi escolhido.");

          for (const [sceneId, optionId] of entries) {
            const scene = scenes[sceneId];
            if (!scene || !scene.options.some((option) => option.id === optionId)) {
              throw new TypeError(`Escolha inválida para ${sceneId}.`);
            }
          }

          for (const [sceneId, optionId] of entries) state.choices[sceneId] = optionId;
          saveState();
          updateInterface();

          return {
            completedFragments: completedCount(),
            complete: completedCount() === 5,
            collectedWords: sceneOrder.map(selectedOption).filter(Boolean).map((option) => option.token)
          };
        }
      })
    ).catch(reportRegistrationError);

    void Promise.resolve(
      context.registerTool({
        name: "read_body_progress",
        title: "Ler progresso do corpo",
        description: "Lê as regiões já respondidas e, quando completo, devolve o corpo-texto composto.",
        inputSchema: { type: "object", properties: {}, additionalProperties: false },
        annotations: { ...commonAnnotations, readOnlyHint: true },
        execute() {
          const complete = completedCount() === 5;
          return {
            completedFragments: completedCount(),
            regions: Object.fromEntries(
              sceneOrder.map((sceneId) => [sceneId, selectedOption(sceneId)?.token || null])
            ),
            bodyText: complete ? endingAsText() : null
          };
        }
      })
    ).catch(reportRegistrationError);
  } catch {
    reportRegistrationError();
  }
}

const discoveries = [["costura", "Alguém me ensinou a esconder a costura. Passei anos chamando de defeito o lugar onde eu conseguia me manter de pé."], ["testa", "Na testa, uma dobra guarda o esforço de entender cedo demais. Desfaço a pergunta por um instante. O papel não precisa saber tudo."], ["herança", "Recebi uma maneira de abaixar a cabeça. Ela vinha embrulhada em cuidado. Separar o gesto do amor que o trouxe ainda me custa."], ["margem", "A margem estava desenhada antes de eu chegar. Encostei nela tantas vezes que começaram a chamar de natureza o que era cerca."], ["rasura", "Rasurei meu nome num caderno. A marca ficou mais funda do que as letras. Até o apagamento aprende a deixar assinatura."], ["domingo", "Era domingo quando percebi que estava descansando com os ombros tensos. A casa estava quieta. Meu corpo ainda esperava uma ordem."], ["fresta", "Pela fresta entrava a conversa da rua. Eu não via quem falava, mas reconhecia o mundo pelo intervalo entre duas risadas."], ["retrato", "No retrato, pediram que eu ficasse parada. Ninguém fotografou o esforço de parecer à vontade."], ["avesso", "O avesso também encosta na pele. Talvez por isso certas coisas que ninguém vê sejam as primeiras a doer."], ["cola", "A cola seca sem consultar o papel. Às vezes, para mudar uma camada de lugar, preciso aceitar que uma parte venha junto."], ["ausência", "Há um espaço aqui que eu costumava preencher depressa. Hoje deixei vazio. Passou uma tarde inteira sem que o mundo acabasse."], ["língua", "Na mesa, uma palavra mudou de sentido conforme a boca que a disse. Guardei o som. Ainda procuro onde colocá-lo."], ["cansaço", "O cansaço não tinha nome bonito. Era uma sacola pousada no chão, a marca da alça na mão, alguns minutos sem responder."], ["dobra", "Dobrei o papel para que coubesse no bolso. Quando abri, a linha continuava lá. Caber deixa vestígios."], ["ruído", "Um portão bate. Antes que eu pense, os ombros respondem. Há memórias que não precisam formar uma imagem."], ["quase", "Quase disse. Depois, no caminho de casa, falei a frase inteira para ninguém. O vento não me interrompeu."], ["sede", "Aprendi a oferecer água antes de perceber minha sede. Hoje o copo ficou um instante na minha mão."], ["intervalo", "Entre ouvir meu nome e responder, existe um espaço pequeno. Tenho tentado morar nele sem pressa."], ["nó", "O nó não se soltou quando entendi de onde vinha. Passei a tarde desfazendo uma volta de cada vez."], ["tato", "Um tecido áspero roça o pescoço. Volto a uma casa que já mudou de cor. A pele insiste em conservar certos endereços."], ["peso", "Ninguém colocou o peso de uma vez. Foi uma coisa pequena por dia. Por isso demorei a perceber que andava inclinada."], ["apoio", "Lembro de uma mão nas minhas costas. Não me empurrou. Ficou ali até que eu encontrasse onde apoiar o pé."], ["pele", "Debaixo desta camada há outra. Não sei se a última me explicaria melhor. Talvez eu só acabasse com menos corpo."], ["calor", "O calor ficou na cadeira depois que a pessoa saiu. Algumas presenças demoram mais do que nós para ir embora."], ["janela", "Abri a janela sem arrumar a casa antes. A luz entrou do mesmo jeito."], ["ombro", "O ombro guarda o lado em que carrego as coisas. Um dia troquei a sacola de mão e estranhei a rua inteira."], ["chão", "Encostei os pés no chão frio. Por alguns segundos não precisei explicar de onde vinha nem aonde pretendia chegar."], ["remendo", "O remendo tinha uma cor diferente. Fingi que não se via. Depois escolhi uma linha que o tornava ainda mais visível."], ["pulso", "Encostei dois dedos no pulso enquanto esperava. Havia uma coisa acontecendo em mim que não dependia da resposta."], ["inacabado", "Deixei um pedaço sem colar. Amanhã posso querer movê-lo. Esta noite, o corpo permanece assim."]];
const discoveryRelations = {
  costura: ["chest", "eyes"], testa: ["eyes", "chest"], herança: ["eyes", "chest"],
  margem: ["nape", "eyes"], rasura: ["mouth", "eyes"], domingo: ["chest", "nape"],
  fresta: ["chest", "mouth"], retrato: ["eyes", "chest"], avesso: ["chest", "eyes"],
  cola: ["chest", "nape"], ausência: ["chest", "throat"], língua: ["mouth", "throat"],
  cansaço: ["nape", "chest"], dobra: ["chest", "eyes"], ruído: ["nape", "chest"],
  quase: ["mouth", "throat"], sede: ["chest", "mouth"], intervalo: ["throat", "mouth"],
  nó: ["throat", "chest"], tato: ["chest", "nape"], peso: ["nape", "chest"],
  apoio: ["chest", "nape"], pele: ["chest", "eyes"], calor: ["chest", "nape"],
  janela: ["eyes", "chest"], ombro: ["nape", "chest"], chão: ["chest", "nape"],
  remendo: ["chest", "eyes"], pulso: ["chest", "throat"], inacabado: ["chest", "eyes"]
};
const connectionLabels = {
  costura: ["O que me manteve de pé ainda bate no peito.", "Quero lembrar quem me ensinou a esconder a costura."],
  testa: ["Minha cabeça ainda tenta compreender antes que aconteça.", "O esforço de entender cedo demais desceu para o peito."],
  herança: ["Que parte desse gesto ainda pensa por mim?", "O cuidado e o medo chegaram juntos ao peito."],
  margem: ["Meu corpo ainda espera os olhos que vigiavam a borda.", "Quero descobrir quem desenhou essa margem na minha cabeça."],
  rasura: ["Quero dizer o nome que ainda aparece sob o risco.", "Minha cabeça guardou até aquilo que tentei apagar."],
  domingo: ["A casa está quieta, mas meu peito ainda espera.", "Meus ombros continuam atentos a uma ordem que não veio."],
  fresta: ["As vozes da rua ainda respiram no meu peito.", "Quero repetir a palavra que atravessou a janela."],
  retrato: ["Quero olhar para o que o retrato não conseguiu guardar.", "Meu peito reconhece quem saiu do enquadramento."],
  avesso: ["O que ninguém via foi o que primeiro doeu no peito.", "Quero olhar para o trabalho escondido atrás da imagem."],
  cola: ["Meu peito ainda guarda as partes que vieram juntas.", "O que ficou para trás continua tocando minhas costas."],
  ausência: ["Quero sentir o tamanho exato do espaço que ficou.", "Há uma palavra ausente parada na minha garganta."],
  língua: ["Quero escutar como essa palavra muda na minha boca.", "O sentido que não encontrei ainda prende minha garganta."],
  cansaço: ["Meus ombros sabem o peso que eu demorei a nomear.", "O peito percebeu tarde demais que precisava parar."],
  dobra: ["Meu peito conserva as formas que precisei assumir.", "Quem me ensinou que eu precisava caber?"],
  ruído: ["Meus ombros respondem antes que eu reconheça o som.", "O portão bateu; meu peito ainda não sabe que foi o vento."],
  quase: ["Quero devolver à boca a frase que chegou tarde.", "A palavra que não saiu continua parada na garganta."],
  sede: ["Quero reconhecer no peito aquilo de que também preciso.", "Minha boca pode beber antes de oferecer o copo."],
  intervalo: ["A pausa começa na garganta antes da resposta.", "Quero ouvir minha boca antes de atender ao chamado."],
  nó: ["Há coisas que compreender não fez atravessar a garganta.", "Meu peito ainda sente cada volta que tento desfazer."],
  tato: ["Minha pele encontrou uma casa que o peito não esqueceu.", "O tecido roça o lugar onde meu corpo aprendeu a vigiar."],
  peso: ["Meus ombros sabem como o peso foi chegando.", "Quero escutar o peito antes de levantar a sacola outra vez."],
  apoio: ["Meu peito reconhece a presença que não exigiu nada.", "Quero lembrar que nem toda mão nas costas empurra."],
  pele: ["Meu peito também foi feito dessas camadas.", "Quero olhar sem procurar uma versão mais verdadeira de mim."],
  calor: ["O peito ainda reconhece quem já deixou a cadeira.", "Minhas costas sentem a presença depois que ela vai embora."],
  janela: ["Quero olhar sem arrumar a casa antes.", "A luz tocou também aquilo que eu escondia no peito."],
  ombro: ["Quero escutar o lado do corpo que sempre carregou.", "Meu peito estranha a rua quando o peso muda de lugar."],
  chão: ["Meu peito pode descansar sem explicar aonde vai.", "O corpo encontra apoio quando já não precisa vigiar atrás."],
  remendo: ["Meu peito conhece o tecido que a linha manteve junto.", "Quero olhar para a marca sem transformá-la em defeito."],
  pulso: ["Meu peito continua enquanto a resposta não chega.", "A espera sobe até a garganta, mas a batida não para."],
  inacabado: ["Meu peito pode permanecer sem uma forma definitiva.", "Quero olhar para o que ainda não precisa terminar."]
};
const discoveryContinuations = {
  costura: [
    ["Passo o dedo sobre a linha. Ela não desaparece."],
    ["Durante muito tempo achei que permanecer de pé significava não deixar ninguém perceber o trabalho que isso dava. Escondia o avesso, aparava as pontas, respondia que estava tudo bem antes mesmo que perguntassem.", "Só depois entendi que algumas partes de mim não foram consertadas. Foram aproximadas com o que havia: uma linha diferente, uma mão sem prática, a urgência de continuar."],
    ["Hoje não procuro uma pele sem marcas. Procuro reconhecer quem segurou a agulha e o que eu precisei juntar para chegar até aqui."]
  ],
  testa: [
    ["A pergunta continua ali, mas diminuo a luz sobre ela."],
    ["Aprendi cedo a observar o rosto das pessoas antes de entrar num cômodo. Pela testa, pela boca, pelo modo como uma cadeira era puxada, eu tentava descobrir que versão do dia me esperava.", "Chamavam de maturidade. Eu sabia que era atenção demais para uma criança, mas ainda não tinha palavras para dizer que compreender tudo também podia ser uma forma de medo."],
    ["Agora deixo uma pergunta sem resposta. Nada acontece. O mundo continua, e minha cabeça não precisa vigiá-lo inteiro."]
  ],
  herança: [
    ["Abaixo a cabeça e reconheço um gesto que não começou em mim."],
    ["Vi mulheres da minha família diminuírem a voz para que uma conversa não se transformasse em outra coisa. Aprendi com elas uma prudência que talvez tenha nos protegido. Aprendi também a desaparecer um pouco antes de cada conflito.", "Não sei separar com limpeza o cuidado e o medo. Os dois chegaram juntos, ensinados pelas mesmas mãos."],
    ["Levanto a cabeça devagar. Não devolvo o amor; devolvo apenas a parte do gesto que já não me protege."]
  ],
  margem: [
    ["Encosto de novo na borda para saber se ela ainda está no mesmo lugar."],
    ["Havia espaços em que eu entrava já pedindo desculpas. Não porque alguém tivesse acabado de me expulsar, mas porque muitas portas anteriores haviam me ensinado a calcular o tamanho da minha presença.", "A margem parecia natural porque estava sempre ali. Só quando tentei atravessá-la percebi quantas vozes trabalhavam para mantê-la parecendo paisagem."],
    ["Dou um passo além da linha. Não acontece nenhuma revelação. Apenas há mais chão do lado de lá."]
  ],
  rasura: [
    ["Ainda consigo ler meu nome por baixo do risco."],
    ["Eu o apaguei com força, como se o papel pudesse esquecer antes de mim. A ponta do lápis atravessou quase toda a folha. Quando virei a página, a marca continuava aparecendo, sem letras, mas com a forma exata do gesto.", "Há apagamentos que preservam melhor do que a escrita. Mostram onde a mão insistiu, onde hesitou, onde desejou não ter deixado prova."],
    ["Escrevo o nome outra vez, não por cima. Ao lado. Quero que as duas tentativas permaneçam visíveis."]
  ],
  domingo: [
    ["Solto um pouco os ombros. Eles tornam a subir."],
    ["A casa estava quieta, mas meu corpo não confiava no silêncio. Eu descansava prestando atenção ao portão, aos passos, à mudança de volume da televisão. Esperava uma ordem que talvez nem viesse.", "Durante anos chamei isso de não saber parar. Era mais antigo: eu não sabia se a pausa tinha sido realmente permitida."],
    ["Fico sentada por mais alguns minutos. O domingo não me pede nada, e tento acreditar nele."]
  ],
  fresta: [
    ["Chego o rosto mais perto sem abrir a janela inteira."],
    ["A rua entrava em pedaços: uma gargalhada, o vendedor chamando, um rádio longe, alguém discutindo o preço de alguma coisa. Eu completava as pessoas sem vê-las, inventava seus gestos a partir das pausas.", "Talvez tenha aprendido ali que uma história não precisa chegar inteira para ocupar uma casa. Às vezes bastava uma voz atravessar a fresta."],
    ["Não abro mais. Também não fecho. Deixo a conversa passar pelo espaço que escolhi."]
  ],
  retrato: [
    ["Olho primeiro para as mãos, não para o sorriso."],
    ["Na fotografia, todo mundo parece ter sabido onde colocar o corpo. Eu vejo o contrário: um pé querendo sair, dedos apertados, um ombro que não encontrou descanso.", "A imagem guardou o segundo em que obedecemos ao pedido de ficar. Não guardou o que aconteceu antes nem a pressa com que nos movemos depois."],
    ["Viro o retrato. Atrás, uma data. Nenhuma explicação para o esforço de parecer à vontade."]
  ],
  avesso: [
    ["Viro uma pequena ponta do papel."],
    ["Do outro lado há cola seca, manchas, linhas interrompidas. Nada foi feito para ser visto, embora seja justamente essa desordem que sustente a superfície.", "Penso em tudo que aprendi a esconder para parecer inteira. Talvez o avesso não revele uma verdade secreta. Talvez revele apenas o trabalho."],
    ["Deixo uma parte virada. Quero lembrar que a imagem também depende do que não mostra."]
  ],
  cola: [
    ["A camada resiste quando tento movê-la."],
    ["Puxo devagar, mas outra parte vem junto. Não existe maneira limpa de separar aquilo que passou muito tempo encostado. Um pedaço guarda a cor do outro; uma borda se desfaz.", "Eu queria reorganizar a memória sem perder nada. A própria matéria me responde que toda mudança deixa restos."],
    ["Paro de puxar. Escolho uma nova posição sabendo que alguma coisa ficará presa à anterior."]
  ],
  ausência: [
    ["Não preencho o espaço."],
    ["Minha primeira vontade é colocar ali uma explicação, uma pessoa, qualquer ruído que me livre de olhar o que falta. Aprendi a agir depressa diante do vazio, como se ele fosse uma acusação.", "Mas a tarde passa. A luz muda na parede. O espaço continua aberto e não exige que eu o transforme em outra coisa."],
    ["Deixo a ausência sem nome. Hoje ela pode ocupar apenas o tamanho que tem."]
  ],
  língua: [
    ["Repito a palavra em silêncio. Na minha boca, ela muda."],
    ["Na mesa, alguém a disse como brincadeira. Outra pessoa ouviu uma ofensa. Eu reconheci uma palavra antiga, usada em casa de um jeito que ninguém ali conhecia.", "O som era o mesmo e não era. Cada boca trazia uma história que a conversa não conseguia acomodar."],
    ["Guardo a palavra sem decidir seu único sentido. Talvez uma língua também seja o lugar onde as versões se encostam."]
  ],
  cansaço: [
    ["Coloco a sacola no chão."],
    ["A marca da alça demora a desaparecer da mão. Não há beleza nisso, nem uma lição escondida. Há o peso comprado, carregado, dividido como foi possível.", "Durante muito tempo só reconheci meu cansaço quando ele já não me deixava continuar. Antes disso, eu o chamava de preguiça, fraqueza ou falta de vontade."],
    ["Abro e fecho os dedos. Por enquanto, não levanto a sacola."]
  ],
  dobra: [
    ["Aliso o papel, mas a linha reaparece."],
    ["Ele coube no bolso porque aceitei dobrá-lo. Quando o retirei, não era menor, apenas trazia no meio a memória da forma que precisou assumir.", "Também meu corpo aprendeu maneiras de caber. Algumas ainda aparecem quando entro em lugares onde já não preciso me dobrar."],
    ["Não tento apagar o vinco. Abro o papel inteiro apesar dele."]
  ],
  ruído: [
    ["O portão bate e meus ombros chegam antes de mim."],
    ["Não vejo nenhuma cena. O corpo não precisa formar uma imagem para reconhecer o som. Ele encurta a respiração, mede a distância até a porta, prepara uma resposta para uma pergunta que ninguém fez.", "Depois descubro que foi apenas o vento. A palavra apenas não desfaz o movimento que já aconteceu."],
    ["Respiro mais uma vez. O portão fica onde está; meus ombros começam a voltar."]
  ],
  quase: [
    ["A frase encosta nos dentes e recua."],
    ["Na conversa, ela pareceu grande demais. Esperei outra oportunidade, uma pausa melhor, um rosto menos fechado. Quando percebi, já estava do lado de fora.", "No caminho de casa, disse tudo em voz alta. A rua recebeu a frase sem concordar nem me interromper."],
    ["Repito apenas o começo. Desta vez, não para ninguém: para que minha boca se acostume a ouvi-lo."]
  ],
  sede: [
    ["Seguro o copo antes de oferecê-lo."],
    ["Eu sabia perguntar se os outros queriam água. Conhecia o barulho da geladeira, o lugar dos copos, a quantidade que cada pessoa costumava beber. Minha própria sede chegava depois, quando a cozinha já estava vazia.", "Hoje percebo a garganta antes de estender a mão. O gesto parece pequeno e, ainda assim, estranho."],
    ["Bebo primeiro. Depois encho o copo outra vez."]
  ],
  intervalo: [
    ["Escuto meu nome e não respondo imediatamente."],
    ["Durante muito tempo, qualquer chamado me puxava por inteiro. Eu respondia antes de saber o que queriam, antes de decidir se podia, antes mesmo de terminar o que estava fazendo.", "Agora existe um intervalo. É curto, mas nele consigo ouvir minha própria voz junto da voz que me chama."],
    ["Respondo depois da pausa. A palavra sai parecida, mas já não pertence somente à urgência do outro."]
  ],
  nó: [
    ["Seguro uma das pontas sem puxar."],
    ["Entender de onde veio não fez o nó desaparecer. Eu sabia quem o apertara, em que dia, por quais medos. Ainda assim, ele permanecia ali, feito também das vezes em que tentei soltá-lo com pressa.", "Comecei por uma volta pequena. Depois outra. Algumas tardes não produziram mais do que um espaço por onde passava a unha."],
    ["O nó ainda existe. Mas agora consigo movê-lo entre os dedos."]
  ],
  tato: [
    ["O tecido roça meu pescoço e a casa volta."],
    ["Não vejo a fachada inteira. Lembro do áspero, do calor preso no quarto, de uma cortina tocando meu braço quando eu passava. A casa já mudou de cor, talvez nem exista do mesmo jeito.", "Minha pele conserva um endereço que meus olhos não conseguiriam encontrar."],
    ["Afasto o tecido. A casa demora alguns segundos para ir embora."]
  ],
  peso: [
    ["Endireito o corpo e percebo quanto vinha carregando."],
    ["Nenhuma coisa parecia suficiente para explicar a inclinação. Era um pedido pequeno, uma preocupação guardada, uma tarefa aceita porque levaria pouco tempo. Depois outra.", "O peso cresceu sem anúncio. Por isso também não sei retirá-lo de uma vez."],
    ["Escolho uma coisa para deixar no chão. Meu corpo ainda se inclina, mas um pouco menos."]
  ],
  apoio: [
    ["A mão continua nas minhas costas sem me apressar."],
    ["Não empurra, não aponta o caminho, não promete que será fácil. Permanece enquanto procuro com o pé um lugar firme.", "Estou acostumada a reconhecer ajuda pelo que ela faz. Demoro a entender essa presença que não toma o movimento para si."],
    ["Encontro onde apoiar o pé. A mão se afasta antes que eu precise agradecer."]
  ],
  pele: [
    ["Levanto uma camada e encontro outra."],
    ["Imagino que, se continuar, chegarei a uma parte mais verdadeira. Mas cada camada esteve em contato com o mundo, protegeu alguma coisa, foi vista ou escondida por algum motivo.", "Retirar tudo não me explicaria. Talvez apenas me deixasse sem as formas que também aprendi a criar."],
    ["Abaixo a camada. Não preciso alcançar uma última pele para reconhecer meu corpo."]
  ],
  calor: [
    ["Encosto a mão no assento ainda morno."],
    ["A pessoa já foi embora, mas a cadeira guarda por alguns minutos uma prova simples de que esteve ali. Não é lembrança ainda. É uma presença atrasada.", "Fico pensando em quantas coisas continuam depois que alguém sai: um copo sobre a mesa, uma frase interrompida, o lugar para onde meu olhar ainda volta."],
    ["O calor diminui sob minha mão. Não tento fazê-lo durar."]
  ],
  janela: [
    ["Abro antes de recolher o que está espalhado."],
    ["Eu costumava preparar a casa para a luz, como se ela viesse examinar a poeira, os papéis, a roupa sobre a cadeira. Naquela manhã, apenas empurrei a janela.", "A claridade entrou sem pedir organização. Tocou o que estava fora do lugar e não transformou nada em vergonha."],
    ["Deixo a janela aberta. Arrumo a casa depois, se quiser."]
  ],
  ombro: [
    ["Passo a sacola para o outro lado."],
    ["O peso não mudou, mas a rua pareceu diferente. Meu corpo havia organizado o caminho inteiro ao redor de um único ombro: o braço livre, a distância das pessoas, o jeito de atravessar.", "Trocar de lado revelou o hábito que eu já não percebia. Também revelou uma dor pequena, acumulada onde eu sempre carregava."],
    ["Caminho alguns metros assim. O outro ombro ainda não sabe, mas aprende."]
  ],
  chão: [
    ["O frio sobe pela planta dos pés."],
    ["Por alguns segundos, não preciso explicar de onde vim nem o que pretendo fazer depois. Há apenas o peso do corpo encontrando uma superfície que não exige resposta.", "Costumo procurar chão como quem procura certeza. Talvez ele seja somente isto: algo que me sustenta enquanto continuo sem saber."],
    ["Mexo os dedos dos pés. O chão não promete nada e, ainda assim, permanece."]
  ],
  remendo: [
    ["Escolho uma linha que não combina."],
    ["Primeiro tentei esconder o rasgo. Procurei uma cor parecida, pontos pequenos, um modo de fazer parecer que nada havia acontecido. Quanto mais disfarçava, mais meus olhos voltavam para aquele lugar.", "Depois usei a linha mais visível que encontrei. Não para celebrar a ferida, mas para parar de gastar o corpo fingindo que ela não estava ali."],
    ["O remendo aparece. Também aparece o tecido que ele conseguiu manter junto."]
  ],
  pulso: [
    ["Dois dedos encontram uma batida."],
    ["Eu esperava uma resposta que podia mudar o resto do dia. A tela permanecia apagada, e tudo parecia suspenso do lado de fora.", "No pulso, porém, havia uma coisa acontecendo sem consultar a mensagem. Não era esperança nem calma. Era apenas meu corpo seguindo enquanto eu esperava."],
    ["A resposta ainda não chegou. Retiro os dedos sabendo que a batida continua."]
  ],
  inacabado: [
    ["A borda solta se move quando respiro."],
    ["Minha primeira vontade é terminar, colar, decidir a posição definitiva. Aprendi a desconfiar do que permanece aberto, como se toda pausa fosse abandono.", "Mas amanhã posso querer mover essa parte. Posso descobrir outra camada ou simplesmente escolher deixá-la assim."],
    ["Esta noite, o corpo não termina. Não por falta: porque ainda está vivo."]
  ]
};
discoveries.forEach(([title, prose], index) => {
  const [first, second] = discoveryRelations[title];
  const [firstLabel, secondLabel] = connectionLabels[title];
  scenes['paper' + index] = {
    title,
    prose:[prose],
    options:[],
    discovery:true,
    stay: discoveryContinuations[title],
    paths: [
      { label: firstLabel, next: first },
      { label: secondLabel, next: second },
      {
        label: "Quero ficar um pouco mais aqui."
      }
    ]
  };
});
scenes.eyes.title = "A repartição";
const fragmentIds = [...sceneOrder, ...discoveries.map((_,index)=>'paper'+index)];
const fragmentPositions = [];
// Follow the silhouette: forehead, face, neck, then shoulders.
[[8,35,3,10,12],[21,27,5,10,11],[33,25,5,10,11],[45,29,4,10,11],[57,35,3,10,11],[69,36,3,10,11],[81,9,7,11,9],[91,14,5,14,8]].forEach(([top,left,count,width,height])=>{
  for(let n=0;n<count;n++) fragmentPositions.push({top,left:left+n*width,width,height});
});
const fragmentLayer=document.querySelector('#discoveryFragments');
fragmentIds.forEach((id,index)=>{
  const b=document.createElement('button');
  const p=fragmentPositions[index];
  b.type='button';b.className='body-fragment discovery-fragment';b.dataset.scene=id;
  b.style.cssText=`top:${p.top}%;left:${p.left}%;width:${p.width}%;height:${p.height}%;--rotate:${index%2?2:-2}deg`;
  b.setAttribute('aria-label', 'Descobrir '+scenes[id].title);
  fragmentLayer.append(b);
});
document.querySelectorAll("[data-scene]").forEach((button) => {
  button.addEventListener("click", () => {
    playFragmentSound(button.dataset.scene);
    travelToScene(button.dataset.scene);
  });
});

elements.startButton.addEventListener("click", startGame);
elements.closePanel.addEventListener("click", closeScene);
elements.readBodyButton.addEventListener("click", showEnding);
elements.closeEnding.addEventListener("click", closeEnding);
elements.copyEnding.addEventListener("click", copyEnding);
elements.printEnding.addEventListener("click", () => window.print());
elements.restartButton.addEventListener("click", () => {
  resetGame();
  elements.startScreen.hidden = false;
  elements.startScreen.classList.remove("is-leaving");
  state.started = false;
  window.setTimeout(() => elements.startButton.focus(), 80);
});
elements.soundToggle.addEventListener("click", toggleSound);
elements.aboutButton.addEventListener("click", () => elements.aboutDialog.showModal());
elements.closeAbout.addEventListener("click", () => elements.aboutDialog.close());
elements.aboutDialog.addEventListener("click", (event) => {
  if (event.target === elements.aboutDialog) elements.aboutDialog.close();
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Tab" && !elements.readingRail.hidden && elements.readingRail.classList.contains("literary-reading")) {
    const buttons = Array.from(elements.readingRail.querySelectorAll("button")).filter(button => !button.closest("[hidden]"));
    const first = buttons[0], last = buttons[buttons.length - 1];
    if (event.shiftKey && (document.activeElement === first || document.activeElement === elements.sceneTitle)) {
      event.preventDefault(); last?.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault(); first?.focus();
    }
  }
  if (event.key === "Escape" && !elements.scenePanel.hidden && !elements.aboutDialog.open) {
    closeScene();
  }
});

loadState();
updateInterface();
registerWebMcpTools();
