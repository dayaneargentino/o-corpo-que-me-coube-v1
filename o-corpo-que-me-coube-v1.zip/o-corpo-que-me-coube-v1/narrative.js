// Remendo 01: texto-base aprovado e continuações literárias.
const headNarrative = {
  "partida": {
    "title": "A repartição",
    "prose": [
      "Minha mãe separava meu cabelo com a unha do dedo mínimo. Fazia uma linha da testa até a nuca e, quando eu me mexia, precisava começar de novo. Entre os joelhos dela, sentada num banco baixo, eu conhecia apenas uma parte de seu rosto: a que aparecia no espelho do guarda-roupa, cortada pela mancha que subia de um dos cantos. Às vezes sua boca continuava se movendo dentro da mancha. Eu ouvia o que dizia, mas não conseguia ver se estava zangada.",
      "Guardo dessa época uma quantidade de coisas que não sei onde pôr. O pente com dois dentes quebrados. O creme acumulado na rosca da tampa. A pressão dos joelhos quando ela precisava alcançar o outro lado. Há lembranças que conto com tanta segurança que desconfio de tê-las terminado depois, acrescentando o que faltava para que alguém pudesse compreendê-las. Digo, por exemplo, que minha mãe penteava meu cabelo aos domingos. Mas quem fazia nossas tranças nos outros dias? Quem tinha tempo? Minha cabeça aparece pronta em todas as fotografias.",
      "Se eu perguntasse a ela, talvez dissesse que não se lembra. Temos essa dificuldade: certas coisas que para mim ocuparam uma infância inteira cabem, para ela, num movimento da mão, numa resposta dada enquanto procura os óculos. Tenho vontade de insistir, de exigir que se sente, que abandone por um momento a vida que continuou tendo depois da minha infância. Mas então ela me pede que procure atrás da almofada, encontro os óculos, entrego, e já estamos falando de outra coisa.",
      "É na mão que penteia que minha lembrança se atrapalha. A mesma mão podia me trazer para perto com uma delicadeza que ainda procuro e, pouco depois, apertar meu braço até eu entender que devia ficar quieta. Durante anos tentei separar as duas, conservar uma mãe de cada lado, como ela separava meu cabelo. Sempre sobrava alguma coisa na divisão. Um carinho dentro de uma tarde que eu preferia esquecer. A vergonha de sentir saudade.",
      "Enquanto ela desembaraçava os fios, eu acompanhava os sons da casa pelo espelho. Não via o corredor, mas havia uma alteração em seu rosto quando alguém entrava nele. Eu suspendia o movimento dos pés. Ela deixava o pente encostado na minha cabeça. Não sei quanto durava. Na lembrança, ainda esperamos.",
      "Depois ela retomava a trança, às vezes apertando mais do que antes. Eu dizia que doía. Ela respondia que estava quase acabando. Essa conversa, ao menos, tenho certeza de que aconteceu muitas vezes: eu dizendo onde doía, ela dizendo quanto faltava."
    ],
    "choices": [
      {
        "label": "O que minha mãe veria nesse espelho?",
        "next": "espelho"
      },
      {
        "label": "Por que tenho vergonha de sentir saudade?",
        "next": "saudade"
      },
      {
        "label": "E se eu me levantasse antes de ela terminar?",
        "next": "levantar"
      },
      {
        "label": "A dor que eu não disse ainda aperta minha garganta.",
        "nextScene": "throat"
      }
    ]
  },
  "espelho": {
    "title": "Do outro lado",
    "prose": [
      "Para saber o que minha mãe via, preciso pôr palavras numa boca que, no espelho, eu mal enxergava. É fácil fazê-la pensar aquilo de que preciso agora. Posso dar a ela uma preocupação, uma ternura escondida, o arrependimento que nunca me contou. Posso até inventar sua infância e fazê-la chegar inteira àquela tarde, explicando a força com que me segurava. Quando percebo, já estou penteando a memória para que nada fique para fora.",
      "O que sei é que havia uma menina entre seus joelhos e uma roupa de trabalho esperando no encosto da cadeira. Minha mãe prendia dois grampos na boca. Dizia alguma coisa sem soltá-los, e eu não entendia; ela precisava tirar os grampos, repetir, recomeçar. Irritava-se com a demora, mas, se uma trança ficasse mais grossa que a outra, desmanchava as duas. Eu achava injusto. Para mim estava pronto. Ela virava minha cabeça de um lado para o outro e encontrava um defeito que eu não conseguia ver.",
      "Anos depois, ouvi alguém dizer que minha mãe sempre me levara muito bem-arrumada à escola. Ela recebeu o elogio com um pequeno movimento do rosto. Eu estava ao lado. Tive vontade de contar quanto doía desfazer as tranças à noite, mas havia café sendo servido, e a conversa já encontrara outro assunto. Também tive vontade de encostar a cabeça em seu ombro. Nenhuma das duas coisas chegou a acontecer.",
      "Naquela visita, ela ajeitou a gola da minha blusa antes de irmos embora. Levantei o queixo para facilitar. Só no elevador reparei no gesto."
    ],
    "choices": [
      {
        "label": "Quero fazer a pergunta que adiei.",
        "next": "pergunta"
      },
      {
        "label": "Quero voltar à vontade de encostar a cabeça.",
        "next": "saudade"
      }
    ]
  },
  "saudade": {
    "title": "O que ainda procuro",
    "prose": [
      "Às vezes reconheço o cheiro do creme numa pessoa que passa e viro o rosto. Leva um instante até que eu me lembre do que estou procurando. Não é minha mãe; ou também é, mas de uma maneira que não caberia numa ligação. Se eu telefonasse e dissesse que senti saudade, ela perguntaria quando vou aparecer, contaria que o preço de alguma coisa subiu, talvez reclamasse que não tenho ligado. Eu precisaria responder a essa mulher que continua vivendo, enquanto a outra permaneceria sentada, com o pote aberto sobre o joelho.",
      "Tenho receio de que uma lembrança boa seja usada contra o que ainda me custa dizer. Como se, ao admitir que havia prazer naquela proximidade, eu tivesse de retirar alguma coisa do que contei antes. Por isso às vezes omito a parte em que ela terminava, passava a palma da mão sobre os fios e me deixava olhar. Eu virava de costas para o espelho, torcia o pescoço, pedia que ela segurasse outro espelho atrás de mim. Queria me ver de todos os lados. Queria ir à rua.",
      "A menina que queria ir à rua é difícil de acomodar na história que aprendi a contar. Ela ri em fotografias que eu chego a examinar com desconfiança. Procuro uma prova na posição de seus braços, na maneira como se aproxima da mãe, e me envergonho de interrogá-la assim. De exigir dela, tantos anos depois, uma expressão que me ajude.",
      "Numa das fotografias, estou saindo do enquadramento. Só ficaram uma trança e a manga do vestido. Alguém escreveu a data atrás. Não consigo lembrar para onde eu ia."
    ],
    "choices": [
      {
        "label": "Quero olhar o que ficou fora da fotografia.",
        "next": "fotografia"
      },
      {
        "label": "Quero experimentar levantar do banco.",
        "next": "levantar"
      }
    ]
  },
  "levantar": {
    "title": "A trança pela metade",
    "prose": [
      "Na primeira vez em que imagino levantar, minha mãe me solta imediatamente. A facilidade estraga a cena. Reconheço ali uma concessão minha, feita muitos anos depois, num quarto em que já posso fechar a porta. Volto ao banco. Minha cabeça ainda está inclinada, o pente preso na metade de uma mecha.",
      "Tento outra vez. Apoio as mãos nos joelhos, estico as pernas. Ela pergunta aonde vou, e descubro que não preparei uma resposta. Queria me levantar; não tinha pensado na obrigação de explicar por quê. Digo que vou beber água. Essa resposta me parece possível. Caberia na boca da menina, não exigiria dela as palavras que só aprendi muito depois.",
      "Minha mãe segura a mecha por mais um instante. É aí que minha invenção hesita. Posso fazê-la puxar, posso fazê-la abrir a mão. A cada tentativa percebo que estou pedindo àquela criança que produza um acontecimento capaz de mudar tudo o que veio depois. Ela só está com sede. Ou disse que estava. O copo fica numa prateleira que talvez ainda não alcance.",
      "Deixo que chegue à cozinha. Vai com uma trança pronta e o resto do cabelo solto, os pés descalços, um fio de creme perto da orelha. A água sai morna da torneira. Ela bebe devagar, escuta se a chamam. Por enquanto ninguém chama."
    ],
    "choices": [
      {
        "label": "Quero ficar na cozinha mais um pouco.",
        "next": "cozinha"
      },
      {
        "label": "Quero voltar sem terminar a trança.",
        "next": "partida"
      }
    ]
  },
  "pergunta": {
    "title": "O pente",
    "prose": [
      "Numa visita, procuro o pente na gaveta onde ela guarda o que não tem mais lugar. Há contas antigas, uma pilha solta, fotografias pequenas demais para os álbuns, um botão embrulhado num recibo. Minha mãe pergunta o que perdi. Digo que nada. Ela vem procurar comigo.",
      "Não sei como começar a pergunta sem decidir de antemão o que quero ouvir. Você lembra que doía? Você sabia? Por que continuava? Cada formulação a põe num lugar diferente, e eu experimento todas enquanto remexo a gaveta. Ela encontra uma fotografia minha e a ergue perto da janela. Reclama da vista. Volto a procurar seus óculos, dessa vez na minha bolsa, onde os guardei minutos antes sem perceber.",
      "Quando entrego os óculos, digo que me lembro das tranças muito apertadas. Minha mãe continua olhando a fotografia. Passa a unha sobre uma mancha, como se fosse possível removê-la. Espero. A geladeira faz aquele ruído que, naquela casa, sempre precedeu o silêncio do motor.",
      "Eu tinha pouco tempo, ela diz. Fico com a mão na borda da gaveta. Não sei se respondeu à minha pergunta ou se trouxe uma que ainda não sei fazer."
    ],
    "choices": [
      {
        "label": "Quero escutar essa resposta de outro lugar.",
        "next": "espelho"
      },
      {
        "label": "Quero reler a lembrança desde o começo.",
        "next": "partida"
      }
    ]
  },
  "fotografia": {
    "title": "Fora do enquadramento",
    "prose": [
      "Viro a fotografia de novo. A data foi escrita com tanta força que marcou o papel do outro lado. Reconheço a letra de uma tia. Há um número corrigido, mas não sei qual veio primeiro; também aqui alguém precisou decidir como se lembraria.",
      "Sei que estava calor porque meu irmão aparece sem camisa ao fundo. A mão de uma pessoa entra pela borda, segurando um prato. Ninguém, na imagem, olha para mim. Isso me dá uma espécie de descanso. Posso ter saído para buscar alguma coisa, para atender alguém no portão, ou simplesmente porque me cansei de esperar que terminassem de tirar a foto.",
      "Minha mãe está sentada. Vejo melhor agora: não olha para a câmera, olha para a mão que oferece o prato. Sua expressão ainda não se resolveu. Se a fotografia tivesse sido tirada um instante depois, talvez fosse outra a mulher que eu passaria anos examinando.",
      "Deixo a foto sobre a mesa e vou buscar água. Quando volto, a luz mudou de lugar. Há uma parte do rosto dela que já não consigo distinguir sem me aproximar."
    ],
    "choices": [
      {
        "label": "Quero me aproximar do rosto dela.",
        "next": "espelho"
      },
      {
        "label": "Quero voltar ao que o cheiro trouxe.",
        "next": "saudade"
      }
    ]
  },
  "cozinha": {
    "title": "Enquanto a água corre",
    "prose": [
      "Ela alcança o copo. Prefiro que alcance. Na minha cozinha de agora, posso decidir ao menos a altura de uma prateleira. O difícil é não encher aquele intervalo com as coisas que gostaria de ter sabido: digo a mim mesma que vou deixar a menina beber água, mas logo estou ao lado dela, querendo explicar a casa.",
      "Do quarto vem o ruído da tampa sendo enroscada. Minha mãe guardou o creme ou apenas o fechou para não ressecar? A menina apoia o copo na pia. Examina a marca úmida que ficou debaixo dele, passa o dedo, faz um caminho até a torneira. Há tempo para isso. Eu tinha esquecido que também havia tempo para coisas assim.",
      "Talvez ela volte. Talvez a chamem. Não consigo imaginar a tarde inteira sem começar a distribuí-la entre uma reparação e um desastre. Então paro aqui, antes de escolher por ela. A trança pronta encosta em suas costas; do outro lado, o cabelo solto prende um pouco do calor da cozinha.",
      "O copo continua na pia quando afasto a mão da tela."
    ],
    "choices": [
      {
        "label": "Quero voltar ao banco e olhar outra vez.",
        "next": "partida"
      },
      {
        "label": "Quero procurar a menina na fotografia.",
        "next": "fotografia"
      }
    ]
  }
};
