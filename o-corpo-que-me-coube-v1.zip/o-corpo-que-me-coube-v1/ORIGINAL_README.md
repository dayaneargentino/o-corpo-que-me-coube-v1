# O corpo que me coube

Jogo breve de literatura digital para navegador. O leitor toca em cinco regiões de um corpo-colagem, escolhe como responder a cada passagem e recebe ao final um corpo-texto composto pelo próprio percurso.

## Abrir localmente

Abra `dist/index.html` em um navegador moderno. O progresso fica somente no dispositivo em que a experiência é aberta.

## Estrutura

- `dist/index.html`: interface e estrutura acessível.
- `dist/styles.css`: direção visual, movimento e adaptação para celular.
- `dist/script.js`: narrativa, ramificações, som e composição do desfecho.
- `dist/assets/corpo-colagem.webp`: personagem original da experiência.
