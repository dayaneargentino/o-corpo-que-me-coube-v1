# Contribuições

Este repositório publica uma obra autoral para consulta e preservação. Não são solicitados pull requests nem alterações de terceiros. A licença aplicável é CC BY-NC-ND 4.0 para o conteúdo original (veja LICENSE.md), ressalvados materiais de terceiros.
